%ex03

f=@(x) -exp(-abs(4*x).^2);

n=9;
xnodes=linspace(-1,1,9);

p=polyfit(xnodes,f(xnodes),9);
xval=polyval(p,0.95)

s=spline_nat(xnodes,f(xnodes),0.95,1,[0 0])

plot(xplot, f(xplot),'linewidth',2)
hold on
plot(0.95, xval,'b*')
plot(0.95, s,'ro')
