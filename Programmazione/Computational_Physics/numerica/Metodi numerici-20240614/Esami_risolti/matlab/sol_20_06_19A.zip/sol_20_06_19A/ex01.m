%ex01

clc
close all
clear all

%definisco i dati
T=1; 
h=0.04;

f=@(t,y) -y+2*t+2;
y0=2;
y_ex=@(t) 2*(exp(-t)+t);

[t_h,u_h,iter_pf]=eulero_indietro(f,0,T,y0,h);
format long
disp('la soluzione al tempo t=1 e')
u_h(end)
disp('la soluzione esatta al tempo t=1 e')
y_ex(T)

err=[];

for h=[0.04 0.02 0.01]
   [t_h,u_h,iter_pf]=eulero_indietro(f,0,T,y0,h);
   err=[err abs(u_h(end)-y_ex(T))];
end

loglog([0.04 0.02 0.01],err,'linewidth',2)
hold on
loglog([0.04 0.02 0.01],[0.04 0.02 0.01],'color','r','linewidth',2)
grid on
legend('errore','h','FontSize',14)

xlabel('h','FontSize',14)
ylabel('err','FontSize',14)