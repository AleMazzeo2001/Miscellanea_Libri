%ex02.m

clc
clear all
close all

f=@(x) (x-pi).*(cos(x)+1);
df=@(x) cos(x)+1 -sin(x)*(x-pi);
a=0;
b=4;
xplot=linspace(a,b,1000);

plot(xplot,f(xplot),'linewidth',2)
grid on

if (f(a)*f(b)<0)
disp('bisezione applicabile')
end

nmax=100;
tol=1.0e-8;
[xvect,xdif,fx,it]=bisez(a,b,nmax,tol,f);
xvect(end)

[xvect,it] = newton(2,nmax,tol,f,df);
xvect(end)